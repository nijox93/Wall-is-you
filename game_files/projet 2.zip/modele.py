#caractères spéciaux grille:  ╬ , ╠ , ╔ , ║ , ╥

#CLASSES
class Dragon():
    def __init__(self, position, niveau):
        self.position = position
        self.niveau = niveau

class Aventurier():
    def __init__(self, position, niveau):
        self.position = position
        self.niveau = niveau

#FONCTIONS
def creer_grille(taille):
    grille = []
    for i in range(taille):
        grille.append([])
        for j in range(taille):
            grille[i].append([True, True, True, True])
    return grille

def connecte(donjon, p1, p2):
    ''' Vérifie si deux salles sont connectées ou pas '''
    portes1, portes2 = donjon[p1[0]][p1[1]], donjon[p2[0]][p2[1]]
    if p1[0] == p2[0]:
        return ((portes1[1] and portes2[3])
                or (portes1[3] and portes2[1]))
    elif p1[1] == p2[1]:
        return ((portes1[0] and portes2[2])
                or (portes1[2] and portes2[0]))
    return False

def pivoter(donjon, position):
    ''' Pivote une case '''
    t = donjon[position[0]][position[1]]
    t[0], t[1], t[2], t[3] = t[3], t[0], t[1], t[2]
    donjon[position[0]][position[1]] = t
    return donjon

def Voisines(donjon, position):
    ''' Renvoie les voisines disponibles '''
    voisines = []
    if position[0] > 0:
        p2 = (position[0] - 1, position[1])
        voisines.append(p2)
    if position[1] < len(donjon[0]) - 1:
        p2 = (position[0], position[1] + 1)
        voisines.append(p2)
    if position[0] < len(donjon) - 1:
        p2 = (position[0] + 1, position[1])
        voisines.append(p2)
    if position[1] > 0:
        p2 = (position[0], position[1] - 1)
        voisines.append(p2)
    print(voisines)
    return voisines

def intention(donjon, position, dragons, visite=[]):
    ''' Renvoie une chemin possible de l'aventurier jusqu'au dragon '''
    visite.append(position)
    chemin = []
    if position in dragons:
        return [position]
    voisines = Voisines(donjon, position)
    for voisine in voisines:
        if voisine not in visite:
            if connecte(donjon, position, voisine):
                chemin = intention(donjon, voisine, dragons, visite)
                if chemin != []:
                    return [position] + chemin
    return chemin

#INITIALISATION
donjon = creer_grille(4)
aventurier = Aventurier((0,0), 1)
dragon1 = Dragon((3,3), 1)
dragon2 = Dragon((1,1), 2)
dragons = [dragon1, dragon2]
grille = creer_grille(4)
print(grille)
print(intention(donjon, aventurier.position,
                [dragon1.position, dragon2.position]))